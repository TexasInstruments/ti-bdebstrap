/*
 * There isn't anything here, but the file must not be empty or patch
 * will delete it.
 */
